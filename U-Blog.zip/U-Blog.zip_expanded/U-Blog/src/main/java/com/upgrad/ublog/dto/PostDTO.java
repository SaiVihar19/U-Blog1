package com.upgrad.ublog.dto;

import java.time.LocalDateTime;

/**
 * TODO: 2.1. Declare 6 private instance variables in this class named as postId,
 *  emailId, tag, title, description, timestamp. Out of these 6 variables, postId
 *  will be of type int and timestamp will be of type LocalDateTime
 *  (import java.time.LocalDateTime). Other four variables will be of type String.
 *
 * TODO: 2.2. Provide getters and setters for each of the instance variables.
 *
 * Note: Uncomment the toString() method given below, instead of writing a new one.
 */

public class PostDTO {

	int postId;
	String emailId;
	String tag;
	String title;
	String description;
	   LocalDateTime timestamp;
	/**
	 * @return the postId
	 */
	public final int getPostId() {
		return postId;
	}
	/**
	 * @param postId the postId to set
	 */
	public final void setPostId(int postId) {
		this.postId = postId;
	}
	/**
	 * @return the emailId
	 */
	public final String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public final void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the tag
	 */
	public final String getTag() {
		return tag;
	}
	/**
	 * @param tag the tag to set
	 */
	public final void setTag(String tag) {
		this.tag = tag;
	}
	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public final void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the description
	 */
	public final String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public final void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the timestamp
	 */
	public final LocalDateTime getTimestamp() {
		return timestamp;
	}
	/**
	 * @param localDateTime the timestamp to set
	 */
	public final void setTimestamp(LocalDateTime localDateTime) {
		this.timestamp = localDateTime;
	}
	
	
	/*@Override
    public String toString() {
        return "PostDTO{" +
                "postId=" + postId +
                ", emailId='" + emailId + '\'' +
                ", tag='" + tag + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }*/

    /*public static void main(String[] args) {
		PostDTO postDTO = new PostDTO();
		postDTO.setPostId(1);
		postDTO.setEmailId("dummy@dummy.com");
		postDTO.setTag("tag");
		postDTO.setTitle("title");
		postDTO.setDescription("Description");
		postDTO.setTimestamp(LocalDateTime.now());

		System.out.println(postDTO);

		 //Your output should be similar to as shown below.
		 //PostDTO{postId=1, emailId='dummy@dummy.com', tag='tag', title='title', description='Description', timestamp=2020-05-22T21:01:34.483363800}

	}*/
}
